module.exports = [
  {
    nickname: 'test',
    server: 'irc.freenode.net',
    discordToken: 'whatapassword',
    ircOptions: {
      encoding: 'utf-8'
    },
    channelMapping: {
      '#discord': '#irc'
    }
  },
  {
    nickname: 'test2',
    server: 'irc.freenode.net',
    discordToken: 'whatapassword',
    ircOptions: {
      encoding: 'utf-8'
    },
    channelMapping: {
      '#discord': '#irc'
    }
  }
];
